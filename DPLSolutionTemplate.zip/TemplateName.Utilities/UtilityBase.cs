﻿using $ext_projectname$.Common.Shared;

namespace $safeprojectname$
{
    public class UtilityBase : ServiceContractBase
    {
    }
}
