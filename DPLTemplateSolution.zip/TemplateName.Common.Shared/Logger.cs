﻿using System;

namespace $safeprojectname$
{
    public class Logger
    {
        public void Error(Exception ex)
        {

        }
        public void Error(string message)
        {

        }

        public void Error(string message, Exception ex)
        {

        }

        public void Info(string message)
        {

        }
        public void Debug(string message)
        {

        }
    }
}
