﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$
{
    public abstract class ManagerTestBase
    {
        public ManagerTestBase()
        {

        }
    }
}
